"Adore 64"  -   Commodore 64 TrueType Font
(c) 2000 by ck!  [Freaky Fonts]

The personal, non-commercial use of my font is free.
But Donations are accepted and highly appreciated!
The use of my fonts for commercial and profit purposes is prohibited,
unless a small donation is send to me.
Contact: ck@freakyfonts.de
These font files may not be modified or renamed.
This readme file must be included with each font, unchanged.
Redistribute? Sure, but send me an e-mail.

If you like the font, please e-mail: 
ck@freakyfonts.de

Visit .:Freaky Fonts:. for updates and new fonts (PC & MAC) :
http://www.freakyfonts.de

Thanks to {ths} for the Mac conversion.
1@ths.nu or visit: http://www.ths.nu

Note:
For best results, use the font at 6 points and its multipliers: 12,18,24......
(Photoshop: 8 points and multipliers.)  
Of course with anti-aliasing turned off.
Cursor   > �
C= Sign  > (c)